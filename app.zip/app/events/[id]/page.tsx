"use client"

import { useParams } from "next/navigation"
import useUser from "@/lib/useUser"
import { Textarea } from "@/components/ui/textarea"
import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabaseClient"
import { getEventCommentsById } from "@/lib/queries"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, MapPin, Users, Clock, ArrowLeft, Share2, Flag } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function EventPage() {
  const params = useParams()
  const id = params?.id as string

  const [event, setEvent] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const user = useUser()
  const [ready, setReady] = useState(false)
  const [newComment, setNewComment] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [isAttending, setIsAttending] = useState(false)

  useEffect(() => {
    if (user && id) setReady(true)
  }, [user, id])

  useEffect(() => {
    if (!id) return

    const fetchEvent = async () => {
      const { data: eventData, error } = await supabase
        .from("events")
        .select(`
      *,
      schedule:event_schedule(time_range, activity),
      attendees:event_attendees(user_id)
    `)
        .eq("id", id)
        .single()

      if (error || !eventData) {
        console.error("Error al cargar el evento:", error)
        setLoading(false)
        return
      }

      // Comentarios (ya con usuario y replies desde su queries.ts)
      const comments = await getEventCommentsById(id)
      eventData.comments = comments || []

      // Organizador
      const { data: organizer } = await supabase
        .from("profiles")
        .select("id, name, username, avatar")
        .eq("id", eventData.user_id)
        .single()

      // PERFILES de asistentes
      const attendeeIds = (eventData.attendees ?? []).map((a: any) => a.user_id)
      let attendeesDetailed: any[] = []
      if (attendeeIds.length > 0) {
        const { data: profiles, error: pfErr } = await supabase
          .from("profiles")
          .select("id, name, username, avatar")
          .in("id", attendeeIds)

        if (pfErr) {
          console.error("Error cargando perfiles de asistentes:", pfErr)
        } else {
          const byId = new Map((profiles ?? []).map(p => [p.id, p]))
          attendeesDetailed = eventData.attendees.map((a: any) => ({
            user_id: a.user_id,
            ...byId.get(a.user_id) // name, username, avatar
          }))
        }
      }

      setEvent({
        ...eventData,
        user: organizer ?? { id: eventData.user_id, name: "Usuario", avatar: null },
        attendees: attendeesDetailed
      })
      setLoading(false)
    }


    fetchEvent()
  }, [id])

  useEffect(() => {
    if (user && event?.attendees) {
      const alreadyAttending = event.attendees.some((a: any) => a.user_id === user.id)
      setIsAttending(alreadyAttending)
    }
  }, [event, user])

  const toggleAttendance = async () => {
    if (!user || !id) return

    if (isAttending) {
      // Cancelar asistencia
      const { error } = await supabase
        .from("event_attendees")
        .delete()
        .eq("event_id", id)
        .eq("user_id", user.id)

      if (!error) {
        setEvent((prev: any) => ({
          ...prev,
          attendees: prev.attendees.filter((a: any) => a.user_id !== user.id)
        }))
        setIsAttending(false)
      } else {
        console.error("Error al cancelar asistencia:", error)
      }
    } else {
      // Confirmar asistencia
      const { data, error } = await supabase
        .from("event_attendees")
        .insert([{ event_id: id, user_id: user.id }])

      if (error) {
        console.error("❌ Error insertando asistencia:", error.message, error.details, error.hint)
      } else {
        console.log("✅ Asistencia registrada:", data)
        setEvent((prev: any) => ({
          ...prev,
          attendees: [...prev.attendees, { user_id: user.id }]
        }))
        setIsAttending(true)
      }
    }
  }


  const handleSubmitComment = async () => {
    if (!newComment.trim() || !user) return
    setSubmitting(true)

    const { data, error } = await supabase
      .from("event_comments")
      .insert([{ event_id: id, user_id: user.id, text: newComment }])
      .select("id, text, created_at")
      .single()

    if (error) {
      console.error("Error al enviar comentario:", error)
    } else {
      const newCommentObj = {
        ...data,
        user: {
          id: user.id,
          name: user?.user_metadata?.name || "Usuario",
          avatar: user.user_metadata.avatar || null
        },
        replies: []
      }
      setEvent((prev: any) => ({ ...prev, comments: [newCommentObj, ...prev.comments] }))
      setNewComment("")
    }
    setSubmitting(false)
  }


  if (!id) return <div className="text-gray-400">Cargando ID del evento...</div>
  if (loading) return <div className="text-gray-400">Cargando evento...</div>
  if (!event) return <div className="text-red-500">Evento no encontrado.</div>

  return (
    <div className="container py-8 px-4 md:px-6">
      <div className="mb-6">
        <Link href="/events" className="inline-flex items-center text-sm text-gray-400 hover:text-white mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver a eventos
        </Link>

        <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-6">
          <Image src={event.image_url || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          <div className="flex-1">
            <div className="flex justify-between items-start mb-4">
              <h1 className="text-3xl font-bold">{event.title}</h1>
              <div className="flex gap-2">
                <Button variant="outline" size="icon">
                  <Share2 className="h-4 w-4" />
                  <span className="sr-only">Compartir</span>
                </Button>
                <Button variant="outline" size="icon">
                  <Flag className="h-4 w-4" />
                  <span className="sr-only">Reportar</span>
                </Button>
              </div>
            </div>

            <div className="flex items-center mb-6">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src={event.user.avatar} alt={event.user.name} />
                <AvatarFallback>{event.user.name.split(" ").map((n: string) => n[0]).join("")}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm text-gray-400">Organizado por</p>
                <Link href={`/profile/${event.user.id}`} className="text-primary hover:underline font-medium">
                  {event.user.name}
                </Link>
              </div>
            </div>

            <div className="space-y-3 mb-8 p-4 bg-gray-900 rounded-lg">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-3 text-gray-400" />
                <span>{event.date}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-3 text-gray-400" />
                <span>{event.time_range}</span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-3 text-gray-400" />
                <div>
                  <p>{event.location}</p>
                  <p className="text-sm text-gray-400">{event.address}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-3 text-gray-400" />
                <span>{event.attendees?.length || 0} / {event.max_attendees} asistentes</span>
              </div>
            </div>

            <Tabs defaultValue="about" className="w-full mb-8">
              <TabsList className="w-full grid grid-cols-3 mb-6">
                <TabsTrigger value="about">Acerca de</TabsTrigger>
                <TabsTrigger value="schedule">Programa</TabsTrigger>
                <TabsTrigger value="attendees">Asistentes</TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="space-y-4">
                <div className="prose prose-invert max-w-none">
                  <p className="text-lg">{event.description}</p>
                  <p>{event.long_description}</p>
                </div>
              </TabsContent>

              <TabsContent value="schedule">
                <div className="space-y-4">
                  {event.schedule.map((item: any, index: number) => (
                    <div key={index} className="flex border-l-2 border-primary pl-4">
                      <div className="min-w-[120px] font-medium">{item.time_range}</div>
                      <div>{item.activity}</div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="attendees">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {event.attendees.map((attendee: any) => (
                    <Link
                      href={`/profile/${attendee.user_id}`}
                      key={attendee.user_id}
                      className="flex items-center p-3 rounded-lg border border-gray-800 hover:bg-gray-800 transition-colors"
                    >
                      <Avatar className="h-12 w-12 mb-2">
                        <AvatarImage src={attendee.avatar || "/placeholder.svg"} alt={attendee.name ?? attendee.username ?? "Usuario"} />
                        <AvatarFallback>{(attendee.username ?? attendee.name ?? "U").substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="text-sm font-medium text-center">{attendee.name ?? attendee.username ?? "Usuario"}</div>
                    </Link>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="mb-8">
              <h2 className="text-xl font-bold mb-4">Comentarios ({event.comments.length})</h2>

              {/* Formulario de nuevo comentario */}
              {true ? (
                <div className="rounded-lg border border-gray-800 p-4 mb-6">
                  <h3 className="font-medium mb-4">Escribe un comentario</h3>
                  <Textarea
                    placeholder="Escribe tu comentario..."
                    className="mb-4 min-h-[120px]"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                  />
                  <div className="flex justify-end">
                    <Button onClick={handleSubmitComment} disabled={!newComment.trim() || submitting}>
                      {submitting ? "Enviando..." : "Publicar comentario"}
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-gray-400 italic">Inicia sesión para dejar un comentario.</p>
              )}

              {/* Comentarios existentes */}
              <div className="space-y-6">
                {event.comments.map((comment: any) => (
                  <div key={comment.id} className="rounded-lg border border-gray-800 p-4">
                    <div className="flex gap-4 items-start">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={comment.user?.avatar || "/placeholder.svg"} />
                        <AvatarFallback>
                          {comment.user?.name?.[0] || "?"}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="text-sm text-gray-400 mb-1">
                          {comment.user ? (
                            <Link href={`/profile/${comment.user.id}`} className="font-medium text-white hover:underline">
                              {comment.user.name ?? comment.user.username ?? "Usuario"}
                            </Link>
                          ) : (
                            <span className="italic text-gray-400">Anónimo</span>
                          )}
                          {" • "}
                          {new Date(comment.created_at).toLocaleDateString()}
                        </div>
                        <p className="text-gray-200 whitespace-pre-line">{comment.text}</p>
                      </div>
                    </div>

                    {/* Respuestas */}
                    {comment.replies.length > 0 && (
                      <div className="pl-12 space-y-4 mt-4">
                        {comment.replies.map((reply: any) => (
                          <div key={reply.id} className="flex gap-3 items-start">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={reply.user?.avatar || "/placeholder.svg"} />
                              <AvatarFallback>
                                {reply.user?.name?.[0] || "?"}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="text-sm text-gray-400 mb-1">
                                {reply.user?.name ? (
                                  <Link href={`/profile/${reply.user.id}`} className="font-medium text-white hover:underline">
                                    {reply.user.name}
                                  </Link>
                                ) : (
                                  <span className="italic text-gray-400">Anónimo</span>
                                )}
                                {" • "}
                                {new Date(reply.created_at).toLocaleDateString()}
                              </div>
                              <p className="text-gray-200">{reply.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="w-full md:w-[300px] space-y-6">
            <div className="p-6 border border-gray-800 rounded-lg">
              <div className="mb-4">
                <p className="text-2xl font-bold mb-1">{event.price}</p>
                <p className="text-sm text-gray-400">por persona</p>
              </div>
              <Button
                className="w-full mb-4"
                onClick={toggleAttendance}
                disabled={!isAttending && event.attendees.length >= event.max_attendees}
                variant={isAttending ? "destructive" : "default"}
              >
                {isAttending ? "Cancelar asistencia" : "Confirmar asistencia"}
              </Button>
              <div className="text-center text-sm text-gray-400">
                <p>Quedan {event.max_attendees - event.attendees.length} plazas disponibles</p>
              </div>
            </div>
            <div className="p-6 border border-gray-800 rounded-lg">
              <h3 className="font-medium mb-3">Comparte este evento</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">Twitter</Button>
                <Button variant="outline" size="sm" className="flex-1">Facebook</Button>
                <Button variant="outline" size="sm" className="flex-1">WhatsApp</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div >
  )
}