// app/profile/[id]/page.tsx
import dynamic from "next/dynamic"

const ProfileClient = dynamic(() => import("./ProfileClient"), { ssr: false })

export default function ProfilePage({ params }: { params: { id: string } }) {
  return <ProfileClient userId={params.id} />
}